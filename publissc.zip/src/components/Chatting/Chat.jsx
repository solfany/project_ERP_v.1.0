// import React from 'react'
// import { BookmarkIcon } from '@react-pdf-viewer/default-layout'
// import walking from './walking.png'
// import bookmark from './bookmark.png'
// import Messages from './Messages'
// import Input from './Input'
// const Chat = ()=> {
//   return (
//     <div className='cchat'>
//         <div className='chatInfo_sub'>
//             <span>wjddnjs</span>
//             <div className='chatIcon_sub'>
//                 <img src={BookmarkIcon}></img>
//                 <img src={walking}></img>
//                 <img src={bookmark}></img>
//             </div>
//         </div>
//         <Messages></Messages>
//         <Input></Input>
//         </div>
//   )
// }

// export default Chat