// import React from 'react'
// import fantasy from './fantasy.png'
// import easteregg from './easteregg.png'
// const Input =() => {
//   return (
//     <div className='message_input'>
//         <input type='text' placeholder='메시지 치던가 말던가'></input>
//         <div className='send_sub'>
//             <img src={fantasy}/>
//             <input type='file' id='file' style={{display:'none'}}></input>
//             <label htmlFor='file'>
//                 <img src={easteregg}/>
//             </label>
//             <button>send</button>
//         </div>
//     </div>
//   )
// }

// export default Input