// import React from 'react'

// const Message=() =>{
//   return (
//     <div className='message_sub owner'>
//         <div className='message_subInfo'>
//             <img src="https://t1.daumcdn.net/friends/prod/editor/dc8b3d02-a15a-4afa-a88b-989cf2a50476.jpg"></img>
//             <span>지금</span>
//         </div>
//         <div className='message_subContent'>
//             <p>hello</p>
//             <img src='https://t1.daumcdn.net/friends/prod/editor/dc8b3d02-a15a-4afa-a88b-989cf2a50476.jpg'></img>
//         </div>
//     </div>
//   )
// }

// export default Message