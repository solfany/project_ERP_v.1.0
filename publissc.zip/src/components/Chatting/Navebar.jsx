// import React, { useContext } from 'react'

// function Navebar() {
    
//   return (
//     <div className='nnavbar'>
//     <span className='llogo'>logo</span>
//     <div className='uuser'>
//         <img className='iimg' src='https://blog.kakaocdn.net/dn/0mySg/btqCUccOGVk/nQ68nZiNKoIEGNJkooELF1/img.jpg'/>
//         <span>john</span>
//         <button className='bbutton'>click</button>
//     </div>
    
//     </div>
//   )
// }

// export default Navebar