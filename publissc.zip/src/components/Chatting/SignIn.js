import React from 'react'
import firebase from 'firebase/compat/auth'
// import { auth } from '../firebase.js'
import { authService , firebaseInstance } from 'Loginbase'
// import {Button} from'mete'
function SignIn() {
const signInWithGoogle = async()=> {
        const provider = new firebaseInstance.auth.GoogleAuthProvider();
        // firebaseInstance.signInWithPopup(provider)
        // provider = new firebaseInstance.auth.GoogleAuthProvider();
        await authService.signInWithPopup(provider);
    }
  return (
    <div>
        <button onClick={signInWithGoogle} >signInWithGoogle</button>
    </div>
  )
}

export default SignIn