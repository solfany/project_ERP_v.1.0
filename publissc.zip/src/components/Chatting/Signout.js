import { authService } from 'Loginbase'
import React from 'react'

function Signout() {
  return (
    <div><button onClick={()=>authService.signOut}>sign out</button></div>
  )
}

export default Signout