import React from "react";
import { Input, Label } from "reactstrap";
import { Table, Row, Col, Button, FormGroup } from "reactstrap";
import { useState, useEffect } from "react";
function EmployeeStatement() {
  // const EmployeePaySlip = ({ employee }) => {
  // 직원 정보를 받아서 해당 직원의 급여 명세서를 보여주는 컴포넌트입니다.

  //

  return (
    <div className="d-flex beetwin">
      <div className="Card"></div>
    </div>
  );
}
export default EmployeeStatement;
