const baseData = [{
    code:'235',
    name:'정원',
    teamName:'영업부',
    position:'신입',
    etc:'휴가 기간',
    vacationType:'휴가 종류',
    day:'총 휴가 일수',
    reason:'신입이 휴가를?'
}]
export default baseData