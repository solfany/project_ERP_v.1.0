import React from "react";

export default () => <span>Edit Profile</span>;