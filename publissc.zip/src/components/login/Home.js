import React from "react";

const Home = () => <span>Home</span>;
export default Home;