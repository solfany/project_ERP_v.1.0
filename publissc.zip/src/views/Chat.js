// import React, { useState, useEffect} from 'react'
// import {db,authService} from 'Loginbase'
// //import SendMessage from './SendMessage'
// import './CHAT.scss'
// import Sidebar from 'components/Chatting/Sidebar'
// import Chat from 'components/Chatting/Chat'
// // import Resister from 'components/Chatting/Resister'
// import Auth from 'components/login/Auth'
// import {useSelector} from 'react-redux'

const App= ()=> {
    return (
        <>
        </>
    )

    // const userObj = useSelector((state) => state.userObj);

    // console.log(userObj)
    
// Add a new document in collection "cities"



















    // const [messages, setMessages] = useState([])
    // useEffect(()=>{
    //     db.collection('messages').orderBy('createdAt').limit(50).onSnapshot(snapshot => {
    //         setMessages(snapshot.docs.map(doc =>doc.data()))
    //     } )
    // },[])
    // console.log(messages)

  
    /*아 몰라 
    <div className='home'>
        <div className='ccontainer'>
            <Sidebar></Sidebar>
            <Chat></Chat>
            </div>

        </div>*/
        
    // <div className='content'>
    // {messages.map(({id, text, photoURL, uid})=>(
    //     <div key={id}>
    //         <img src={photoURL}/>
    //         <p>{text}</p>
    //     </div>
    // ))}
    // <SendMessage/>
    // </div>
  
}

export default App