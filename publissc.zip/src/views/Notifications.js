// import React from "react";
// import { BrowserRouter as Router, Route } from "react-router-dom";
// // import MyComponent from "./routes/MyComponent.js";
// import Xlsx from "./routes/Xlsx.js";

// // reactstrap components
// // import {
// //   Alert,
// //   UncontrolledAlert,
// //   Button,
// //   Card,
// //   CardHeader,
// //   CardBody,
// //   CardTitle,
// //   Row,
// //   Col,
// // } from "reactstrap";

// function Notifications() {
//   return (
//     <Route>
//       {" "}
//       <Router>
//         {/* 라우터를 만들어주고  */}
//         <Xlsx />

//         {/* 그 안에 라우트를 만들고, 누군가 우리 웹사이트의 "/" url에 있다면
//           우리는 Home component 를 보여준다. */}
//       </Router>
//     </Route>
//   );
// }

// export default Notifications;
